#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import random
import string
import re
import os
import sys
import logging
import json
import requests
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, ElementClickInterceptedException, StaleElementReferenceException
import undetected_chromedriver as uc

# ═══════════════════════════════════════════════════════════════════════════════
# 🔧 CONFIGURATION - MODIFIEZ CES VALEURS SELON VOS BESOINS
# ═══════════════════════════════════════════════════════════════════════════════

class Config:    
    # 🌐 Configuration générale
    BOLT_SIGNUP_URL = "https://bolt.new/?rid=ftsvw3"
    TEMP_EMAIL_SERVICE = "https://22.do"
    DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1400582230237253812/tyPAsxrphheCwReUPB0MzdWMEHRRMlN4BCqAg46GVrINYHGv0f70WDef2eWrJp10XQ4T"
    
    # 📊 Configuration des comptes
    ACCOUNT_CREATION_MODE = "infinite"  # Mode infini par défaut
    
    # 🔐 Configuration des mots de passe
    PASSWORD_MODE = "random"  # "random" ou "custom"
    CUSTOM_PASSWORD = "MonMotDePasse123!"
    PASSWORD_LENGTH = 12
    
    # 👤 Configuration des noms d'utilisateur
    USERNAME_LENGTH = 8
    
    # ⏱️ Configuration des timeouts (en secondes)
    EMAIL_CHECK_TIMEOUT = 60
    PAGE_LOAD_TIMEOUT = 20
    ELEMENT_WAIT_TIMEOUT = 10
    FIELD_INPUT_DELAY = 0.2
    PASSWORD_FIELD_DELAY = 0.2
    
    # 📧 Configuration des domaines email autorisés
    ALLOWED_EMAIL_DOMAINS = ["@hotmail.com", "@outlook.com", "@gmail.com"]
    
    # 📁 Configuration des fichiers de sortie
    CREDENTIALS_FILE = "stackblitz_credentials.json"
    LOG_FILE = "stackblitz_automation.log"
    
    # 🎨 Configuration des couleurs (codes ANSI)
    COLORS = {
        'DEBUG': '\033[36m',
        'INFO': '\033[32m',
        'WARNING': '\033[33m',
        'ERROR': '\033[31m',
        'CRITICAL': '\033[35m',
        'RESET': '\033[0m',
        'BOLD': '\033[1m',
        'DIM': '\033[2m',
        'BLUE': '\033[34m',
        'PURPLE': '\033[95m',
        'CYAN': '\033[96m',
    }

# ═══════════════════════════════════════════════════════════════════════════════
# 📊 GESTIONNAIRE DE DONNÉES
# ═══════════════════════════════════════════════════════════════════════════════

class DataManager:
    """Gestionnaire des données des comptes et statistiques"""
    
    def __init__(self):
        self.accounts = []
        self.stats = {
            'total_attempts': 0,
            'successful_accounts': 0,
            'failed_attempts': 0,
            'start_time': datetime.now().isoformat(),
            'last_update': datetime.now().isoformat()
        }
        self.logs = []
        self.load_data()
    
    def load_data(self):
        """Charge les données existantes"""
        try:
            if os.path.exists(Config.CREDENTIALS_FILE):
                with open(Config.CREDENTIALS_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.accounts = data.get('accounts', [])
                    self.stats = data.get('stats', self.stats)
        except Exception as e:
            print(f"Erreur lors du chargement des données: {e}")
    
    def save_data(self):
        """Sauvegarde les données"""
        try:
            data = {
                'accounts': self.accounts,
                'stats': self.stats,
                'last_save': datetime.now().isoformat()
            }
            with open(Config.CREDENTIALS_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Erreur lors de la sauvegarde: {e}")
    
    def add_account(self, email, username, password):
        """Ajoute un nouveau compte"""
        account = {
            'id': len(self.accounts) + 1,
            'email': email,
            'username': username,
            'password': password,
            'created_at': datetime.now().isoformat(),
            'status': 'active'
        }
        self.accounts.append(account)
        self.stats['successful_accounts'] += 1
        self.stats['last_update'] = datetime.now().isoformat()
        self.save_data()
        return account
    
    def add_log(self, level, message):
        """Ajoute un log"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'message': message
        }
        self.logs.append(log_entry)
        # Garder seulement les 1000 derniers logs
        if len(self.logs) > 1000:
            self.logs = self.logs[-1000:]
    
    def update_stats(self, attempts=0, failures=0):
        """Met à jour les statistiques"""
        self.stats['total_attempts'] += attempts
        self.stats['failed_attempts'] += failures
        self.stats['last_update'] = datetime.now().isoformat()
        self.save_data()

# ═══════════════════════════════════════════════════════════════════════════════
# 🔔 GESTIONNAIRE DISCORD WEBHOOK
# ═══════════════════════════════════════════════════════════════════════════════

class DiscordNotifier:
    """Gestionnaire des notifications Discord"""
    
    def __init__(self, webhook_url, data_manager):
        self.webhook_url = webhook_url
        self.data_manager = data_manager
    
    def send_account_notification(self, account):
        """Envoie une notification pour un nouveau compte créé"""
        try:
            embed = {
                "title": "🎉 Nouveau compte StackBlitz créé !",
                "color": 0x00ff00,
                "fields": [
                    {"name": "📧 Email", "value": f"`{account['email']}`", "inline": True},
                    {"name": "👤 Username", "value": f"`{account['username']}`", "inline": True},
                    {"name": "🔐 Password", "value": f"`{account['password']}`", "inline": True},
                    {"name": "🆔 ID", "value": f"#{account['id']}", "inline": True},
                    {"name": "⏰ Créé le", "value": f"<t:{int(datetime.fromisoformat(account['created_at']).timestamp())}:F>", "inline": True}
                ],
                "footer": {"text": "StackBlitz Bot Linux"},
                "timestamp": account['created_at']
            }
            
            payload = {
                "embeds": [embed],
                "username": "StackBlitz Bot",
                "avatar_url": "https://cdn.discordapp.com/attachments/1234567890/stackblitz-logo.png"
            }
            
            response = requests.post(self.webhook_url, json=payload, timeout=10)
            if response.status_code == 204:
                print("✅ Notification Discord envoyée avec succès")
                return True
            else:
                print(f"❌ Erreur Discord: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Erreur lors de l'envoi Discord: {e}")
            return False
    
    def send_stats_notification(self):
        """Envoie un résumé des statistiques"""
        try:
            stats = self.data_manager.stats
            embed = {
                "title": "📊 Statistiques StackBlitz Bot",
                "color": 0x0099ff,
                "fields": [
                    {"name": "✅ Comptes créés", "value": str(stats['successful_accounts']), "inline": True},
                    {"name": "❌ Échecs", "value": str(stats['failed_attempts']), "inline": True},
                    {"name": "🎯 Total tentatives", "value": str(stats['total_attempts']), "inline": True},
                    {"name": "📈 Taux de réussite", "value": f"{(stats['successful_accounts']/max(stats['total_attempts'], 1)*100):.1f}%", "inline": True}
                ],
                "footer": {"text": "StackBlitz Bot Linux - Rapport automatique"},
                "timestamp": datetime.now().isoformat()
            }
            
            payload = {"embeds": [embed]}
            response = requests.post(self.webhook_url, json=payload, timeout=10)
            return response.status_code == 204
            
        except Exception as e:
            print(f"❌ Erreur stats Discord: {e}")
            return False

# ═══════════════════════════════════════════════════════════════════════════════
# 🎨 SYSTÈME DE LOGGING COLORÉ
# ═══════════════════════════════════════════════════════════════════════════════

class ColoredFormatter(logging.Formatter):
    """Formateur de logs avec couleurs pour une sortie élégante"""
    
    def format(self, record):
        color = Config.COLORS.get(record.levelname, Config.COLORS['RESET'])
        reset = Config.COLORS['RESET']
        bold = Config.COLORS['BOLD']
        
        timestamp = datetime.now().strftime('%H:%M:%S')
        level_colored = f"{color}{bold}[{record.levelname}]{reset}"
        message_colored = f"{color}{record.getMessage()}{reset}"
        
        return f"{Config.COLORS['DIM']}{timestamp}{reset} {level_colored} {message_colored}"

class Logger:
    """Gestionnaire de logs avec couleurs et formatage élégant"""
    
    def __init__(self, data_manager=None):
        self.data_manager = data_manager
        self.logger = logging.getLogger('StackBlitzBot')
        self.logger.setLevel(logging.DEBUG)
        
        if self.logger.handlers:
            return
        
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_formatter = ColoredFormatter()
        console_handler.setFormatter(console_formatter)
        
        file_handler = logging.FileHandler(Config.LOG_FILE, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
    
    def info(self, message):
        self.logger.info(message)
        if self.data_manager:
            self.data_manager.add_log('INFO', message)
    
    def warning(self, message):
        self.logger.warning(message)
        if self.data_manager:
            self.data_manager.add_log('WARNING', message)
    
    def error(self, message):
        self.logger.error(message)
        if self.data_manager:
            self.data_manager.add_log('ERROR', message)
    
    def debug(self, message):
        self.logger.debug(message)
        if self.data_manager:
            self.data_manager.add_log('DEBUG', message)
    
    def log_account_info(self, email, username, password, account_number):
        """Affiche les informations de compte de manière élégante"""
        print("\n" + "="*70)
        print(f"🎉 {Config.COLORS['BOLD']}{Config.COLORS['INFO']}COMPTE #{account_number} CRÉÉ AVEC SUCCÈS{Config.COLORS['RESET']} 🎉")
        print("="*70)
        print(f"📧 {Config.COLORS['CYAN']}Email:{Config.COLORS['RESET']}     {email}")
        print(f"👤 {Config.COLORS['CYAN']}Username:{Config.COLORS['RESET']}  {username}")
        print(f"🔐 {Config.COLORS['CYAN']}Password:{Config.COLORS['RESET']}  {password}")
        print("="*70 + "\n")
    
    def log_header(self):
        """Affiche l'en-tête du programme"""
        print(f"\n{Config.COLORS['BOLD']}{Config.COLORS['PURPLE']}")
        print("╔══════════════════════════════════════════════════════════════════════╗")
        print("║                    🤖 STACKBLITZ ACCOUNT CREATOR 🤖                  ║")
        print("║                         Version Linux VPS                            ║")
        print("╚══════════════════════════════════════════════════════════════════════╝")
        print(f"{Config.COLORS['RESET']}")

# ═══════════════════════════════════════════════════════════════════════════════
# 🔧 UTILITAIRES DE GÉNÉRATION
# ═══════════════════════════════════════════════════════════════════════════════

class Generator:
    """Générateur d'identifiants et mots de passe"""
    
    @staticmethod
    def generate_password(length=None):
        """Génère un mot de passe selon la configuration"""
        if Config.PASSWORD_MODE == "custom":
            return Config.CUSTOM_PASSWORD
        
        length = length or Config.PASSWORD_LENGTH
        if length < 3:
            raise ValueError("La longueur doit être d'au moins 3 caractères")

        uppercase = random.choice(string.ascii_uppercase)
        lowercase = random.choice(string.ascii_lowercase)
        digit_or_symbol = random.choice(string.digits + string.punctuation)

        others = random.choices(
            string.ascii_letters + string.digits + string.punctuation, 
            k=length - 3
        )

        password_list = list(uppercase + lowercase + digit_or_symbol + ''.join(others))
        random.shuffle(password_list)
        return ''.join(password_list)
    
    @staticmethod
    def generate_username(length=None):
        """Génère un nom d'utilisateur aléatoire"""
        length = length or Config.USERNAME_LENGTH
        chars = string.ascii_lowercase + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

# ═══════════════════════════════════════════════════════════════════════════════
# 🌐 GESTIONNAIRE DE NAVIGATEUR POUR LINUX
# ═══════════════════════════════════════════════════════════════════════════════

class BrowserManager:
    """Gestionnaire du navigateur Chrome pour Linux"""
    
    def __init__(self, logger):
        self.logger = logger
        self.driver = None
    
    def setup_driver(self):
        """Configure et retourne le driver Chrome pour Linux"""
        self.logger.info("🚀 Initialisation du navigateur Chrome pour Linux...")
        
        options = uc.ChromeOptions()
        
        # Options spécifiques pour Linux/VPS
        options.add_argument('--headless')  # Mode sans interface graphique
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--disable-web-security')
        options.add_argument('--disable-features=VizDisplayCompositor')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-plugins')
        options.add_argument('--disable-images')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        
        try:
            self.driver = uc.Chrome(options=options)
            self.logger.info("✅ Navigateur Chrome initialisé avec succès")
            return self.driver
        except Exception as e:
            self.logger.error(f"❌ Erreur lors de l'initialisation du navigateur: {e}")
            raise
    
    def clean_browser_session(self):
        """Nettoie complètement la session du navigateur"""
        self.logger.info("🧹 Nettoyage de la session navigateur...")
        
        try:
            while len(self.driver.window_handles) > 1:
                self.driver.switch_to.window(self.driver.window_handles[-1])
                self.driver.close()
                time.sleep(0.1)
            
            if self.driver.window_handles:
                self.driver.switch_to.window(self.driver.window_handles[0])
            
            self.driver.delete_all_cookies()
            self.driver.execute_script("window.localStorage.clear();")
            self.driver.execute_script("window.sessionStorage.clear();")
            self.driver.get("about:blank")
            time.sleep(1)
            
            self.logger.info("✅ Session navigateur nettoyée")
            
        except Exception as e:
            self.logger.warning(f"⚠️ Erreur lors du nettoyage : {e}")
    
    def robust_click(self, element, retries=3, wait_time=1):
        """Clic robuste avec gestion d'erreurs"""
        for attempt in range(retries):
            try:
                WebDriverWait(self.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                    EC.visibility_of(element)
                )
                WebDriverWait(self.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                    EC.element_to_be_clickable(element)
                )
                self.driver.execute_script(
                    "arguments[0].scrollIntoView({block: 'center'});", element
                )
                time.sleep(0.2)
                element.click()
                return True
            except ElementClickInterceptedException:
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    return True
                except Exception:
                    pass
            except Exception as e:
                self.logger.warning(f"⚠️ Tentative de clic {attempt+1} échouée : {e}")
            time.sleep(wait_time)
        return False
    
    def robust_send_keys(self, element, text, retries=3, is_password_field=False):
        """Saisie robuste avec ActionChains"""
        field_delay = Config.PASSWORD_FIELD_DELAY if is_password_field else Config.FIELD_INPUT_DELAY

        for attempt in range(retries):
            try:
                WebDriverWait(self.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                    EC.visibility_of(element)
                )
                self.driver.execute_script(
                    "arguments[0].scrollIntoView({block: 'center'});", element
                )
                time.sleep(field_delay)

                element.click()
                time.sleep(0.1)
                element.clear()
                time.sleep(0.1)
                element.send_keys(Keys.CONTROL + "a")
                element.send_keys(Keys.DELETE)
                time.sleep(0.2)

                actions = ActionChains(self.driver)
                for char in text:
                    actions.send_keys(char)
                    actions.pause(0.05)
                actions.perform()

                time.sleep(field_delay)

                final_value = element.get_attribute("value")
                if final_value == text:
                    return True

            except Exception as e:
                self.logger.warning(f"⚠️ Erreur tentative {attempt + 1} : {e}")

            time.sleep(field_delay * 2)

        return False
    
    def close(self):
        """Ferme le navigateur proprement"""
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass

# ═══════════════════════════════════════════════════════════════════════════════
# 📧 GESTIONNAIRE D'EMAIL TEMPORAIRE
# ═══════════════════════════════════════════════════════════════════════════════

class EmailManager:
    """Gestionnaire d'emails temporaires avec 22.do"""
    
    def __init__(self, browser_manager, logger):
        self.browser = browser_manager
        self.logger = logger
    
    def get_temp_email(self):
        """Obtient une adresse email temporaire valide"""
        self.logger.info("📧 Génération d'une adresse email temporaire...")
        self.browser.driver.get(Config.TEMP_EMAIL_SERVICE)

        self._handle_consent()
        
        for attempt in range(20):
            email, domain = self._read_email()
            if email and domain in Config.ALLOWED_EMAIL_DOMAINS:
                self.logger.info(f"✅ Email valide trouvé : {email}")
                return email
            else:
                self.logger.info(f"🔄 Domaine invalide ({domain}), tentative {attempt + 1}/20")
                if not self._generate_new_email():
                    break

        raise Exception("❌ Aucune adresse email valide trouvée.")
    
    def _handle_consent(self):
        """Gère le bouton de consentement s'il apparaît"""
        try:
            consent_p = WebDriverWait(self.browser.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "//p[text()='Consent']"))
            )
            consent_button = consent_p.find_element(By.XPATH, "./ancestor::button")
            self.browser.robust_click(consent_button)
            self.logger.info("✅ Bouton de consentement cliqué.")
        except:
            self.logger.debug("ℹ️ Aucun consentement détecté.")
    
    def _read_email(self):
        """Lit l'adresse email actuelle"""
        try:
            name_input = WebDriverWait(self.browser.driver, 10).until(
                EC.presence_of_element_located((By.ID, "mail-input"))
            )
            email_name = name_input.get_attribute("value")

            domain_elem = WebDriverWait(self.browser.driver, 10).until(
                EC.presence_of_element_located((
                    By.CSS_SELECTOR,
                    "div.choices__item.choices__item--selectable[aria-selected='true']"
                ))
            )
            email_domain = domain_elem.text.strip()
            return email_name + email_domain, email_domain
        except Exception as e:
            self.logger.error(f"❌ Lecture de l'email échouée : {e}")
            return None, None
    
    def _generate_new_email(self):
        """Génère une nouvelle adresse email"""
        try:
            random_btn = WebDriverWait(self.browser.driver, 5).until(
                EC.element_to_be_clickable((By.ID, "mail-random"))
            )
            self.browser.robust_click(random_btn)
            time.sleep(2)
            return True
        except Exception as e:
            self.logger.error(f"❌ Impossible de cliquer sur Random : {e}")
            return False
    
    def wait_for_confirmation_email(self):
        """Attend et traite l'email de confirmation StackBlitz"""
        self.logger.info("📬 Recherche de l'email de confirmation StackBlitz...")
        
        for attempt in range(Config.EMAIL_CHECK_TIMEOUT):
            try:
                if attempt > 0:
                    self.browser.driver.refresh()
                    time.sleep(3)

                self.logger.info(f"🔍 Vérification #{attempt + 1}...")

                from_elements = self.browser.driver.find_elements(By.CSS_SELECTOR, "div.item.from")
                for i, from_elem in enumerate(from_elements):
                    if "hello@stackblitz.com" in from_elem.get_attribute("innerHTML"):
                        self.logger.info("✅ Email StackBlitz trouvé !")
                        
                        if self._process_confirmation_email(i):
                            return True
                        else:
                            return False
                
                time.sleep(3)

            except Exception as e:
                self.logger.warning(f"⚠️ Tentative {attempt + 1} : {e}")
                time.sleep(3)

        self.logger.error("❌ Aucune confirmation StackBlitz trouvée.")
        return False
    
    def _process_confirmation_email(self, email_index):
        """Traite l'email de confirmation trouvé"""
        try:
            subjects = self.browser.driver.find_elements(By.CSS_SELECTOR, "div.item.subject")
            if email_index < len(subjects):
                subject_elem = subjects[email_index]
                self.browser.robust_click(subject_elem)
                self.logger.info("📖 Email de confirmation ouvert.")
                time.sleep(3)

                return self._find_and_click_confirmation_link()
        except Exception as e:
            self.logger.error(f"❌ Erreur lors du traitement de l'email : {e}")
        return False
    
    def _find_and_click_confirmation_link(self):
        """Trouve et clique sur le lien de confirmation"""
        try:
            iframes = self.browser.driver.find_elements(By.CSS_SELECTOR, "iframe")
            for iframe in iframes:
                iframe_src = iframe.get_attribute("src") or ""
                if "22.do/view/" in iframe_src:
                    self.browser.driver.switch_to.frame(iframe)
                    self.logger.info("🔄 Basculé vers l'iframe email.")
                    time.sleep(3)
                    
                    confirmation_link = self._extract_confirmation_link()
                    self.browser.driver.switch_to.default_content()

                    if confirmation_link:
                        self.logger.info(f"🔗 Lien de confirmation trouvé : {confirmation_link}")
                        self.browser.driver.get(confirmation_link)
                        WebDriverWait(self.browser.driver, Config.PAGE_LOAD_TIMEOUT).until(
                            EC.presence_of_element_located((By.TAG_NAME, "body"))
                        )
                        self.logger.info("✅ Confirmation ouverte et page chargée.")
                        return True
                    else:
                        self.logger.warning("⚠️ Aucun lien de confirmation trouvé dans l'iframe.")
                        return False
        except Exception as e:
            self.logger.error(f"❌ Erreur lors de la recherche du lien : {e}")
        return False
    
    def _extract_confirmation_link(self):
        """Extrait le lien de confirmation de l'email"""
        try:
            links = self.browser.driver.find_elements(By.TAG_NAME, "a")
            for link in links:
                href = link.get_attribute("href") or ""
                if "stackblitz.com/users/confirmation" in href and "confirmation_token=" in href:
                    return href
        except Exception as e:
            self.logger.warning(f"⚠️ Erreur lors de la recherche des liens : {e}")
        
        return None

# ═══════════════════════════════════════════════════════════════════════════════
# 🎯 GESTIONNAIRE D'INSCRIPTION STACKBLITZ
# ═══════════════════════════════════════════════════════════════════════════════

class StackBlitzRegistrar:
    """Gestionnaire d'inscription sur StackBlitz/Bolt"""
    
    def __init__(self, browser_manager, logger):
        self.browser = browser_manager
        self.logger = logger
    
    def register_account(self, email):
        """Inscription complète sur Bolt avec l'email fourni"""
        self.logger.info(f"🚀 Ouverture de la page d'inscription : {Config.BOLT_SIGNUP_URL}")
        
        self.browser.driver.execute_script(f"window.open('{Config.BOLT_SIGNUP_URL}', '_blank');")
        WebDriverWait(self.browser.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
            lambda d: len(d.window_handles) > 1
        )
        self.browser.driver.switch_to.window(self.browser.driver.window_handles[1])

        WebDriverWait(self.browser.driver, Config.PAGE_LOAD_TIMEOUT).until(
            EC.presence_of_element_located((By.TAG_NAME, "body"))
        )
        time.sleep(3)

        if not self._click_create_account_button():
            return False, None, None

        time.sleep(5)

        username = Generator.generate_username()
        password = Generator.generate_password()
        
        if self._fill_and_submit_form(email, username, password):
            self.logger.info("💾 Inscription réussie!")
            
            self.browser.driver.switch_to.window(self.browser.driver.window_handles[0])
            if self._open_mailbox_and_confirm():
                return True, username, password
        
        return False, None, None
    
    def _click_create_account_button(self):
        """Trouve et clique sur le bouton 'Create your account'"""
        create_account_selectors = [
            "//button[contains(.,'Create your account')]",
            "//span[text()='Create your account']/parent::button",
            "//button[contains(text(),'Create your account')]",
            "//a[contains(.,'Create your account')]",
            "//button[contains(@class,'create') or contains(@class,'signup') or contains(@class,'register')]"
        ]
        
        for selector in create_account_selectors:
            try:
                create_btn = WebDriverWait(self.browser.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
                if self.browser.robust_click(create_btn):
                    self.logger.info("✅ Bouton 'Create your account' cliqué.")
                    return True
            except:
                continue

        self.logger.error("❌ Aucun bouton 'Create your account' trouvé.")
        return False
    
    def _fill_and_submit_form(self, email, username, password):
        """Remplit et soumet le formulaire d'inscription"""
        max_form_attempts = 3
        
        for form_attempt in range(max_form_attempts):
            try:
                self.logger.info("📝 Remplissage du formulaire d'inscription...")
                
                field_definitions = [
                    ('email', "//input[@type='email' or @name='email' or contains(@placeholder,'mail')]", email, False),
                    ('username', "//input[@name='username' or contains(@placeholder,'sername') or contains(@placeholder,'Username')]", username, False),
                    ('password', "//input[@type='password' and not(@name='password-confirm')]", password, True),
                    ('confirm_password', "//input[@name='password-confirm' or (@type='password' and contains(@placeholder,'confirmation'))]", password, True)
                ]
                
                for field_name, selector, value, is_password in field_definitions:
                    try:
                        field = WebDriverWait(self.browser.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                            EC.presence_of_element_located((By.XPATH, selector))
                        )
                        WebDriverWait(self.browser.driver, 5).until(
                            EC.element_to_be_clickable(field)
                        )
                        
                        if not self.browser.robust_send_keys(field, value, is_password_field=is_password):
                            self.logger.error(f"❌ Échec du remplissage du champ {field_name}")
                            break
                        
                        self.logger.info(f"✅ Champ {field_name} rempli avec succès")
                        
                        if is_password:
                            time.sleep(Config.PASSWORD_FIELD_DELAY * 1.5)
                        else:
                            time.sleep(Config.FIELD_INPUT_DELAY)
                    
                    except TimeoutException:
                        self.logger.warning(f"⚠️ Champ {field_name} non trouvé")
                        break
                    except Exception as e:
                        self.logger.error(f"❌ Erreur avec le champ {field_name}: {e}")
                        break
                else:
                    time.sleep(1)
                    
                    if self._submit_form():
                        return True

            except Exception as e:
                self.logger.error(f"❌ Erreur lors de la tentative {form_attempt + 1} : {e}")
                time.sleep(2)

        return False
    
    def _submit_form(self):
        """Soumet le formulaire d'inscription"""
        submit_selectors = [
            "//button[@type='submit' and contains(., 'Sign Up')]",
            "//button[contains(text(), 'Sign Up')]",
            "//button[@type='submit' and contains(@class, 'registerButton')]",
            "//button[contains(text(), 'Create Account')]",
            "//button[contains(text(), 'Register')]",
            "//button[@type='submit']",
            "//input[@type='submit']"
        ]

        for selector in submit_selectors:
            try:
                submit_btn = WebDriverWait(self.browser.driver, Config.ELEMENT_WAIT_TIMEOUT).until(
                    EC.element_to_be_clickable((By.XPATH, selector))
                )
                if self.browser.robust_click(submit_btn):
                    self.logger.info("✅ Formulaire soumis avec succès!")
                    return True
            except:
                continue

        self.logger.error("❌ Aucun bouton de soumission trouvé.")
        return False
    
    def _open_mailbox_and_confirm(self):
        """Ouvre la boîte mail et confirme l'inscription"""
        try:
            WebDriverWait(self.browser.driver, Config.PAGE_LOAD_TIMEOUT).until(
                EC.presence_of_element_located((By.ID, "into-mailbox"))
            )
            open_btn = self.browser.driver.find_element(By.ID, "into-mailbox")
            self.browser.robust_click(open_btn)
            self.logger.info("📬 Accès à la boîte mail via bouton 'Open'.")
            
            email_manager = EmailManager(self.browser, self.logger)
            return email_manager.wait_for_confirmation_email()
        except Exception as e:
            self.logger.error(f"❌ Impossible de cliquer sur 'Open' : {e}")
            return False

# ═══════════════════════════════════════════════════════════════════════════════
# 🤖 CLASSE PRINCIPALE DU BOT
# ═══════════════════════════════════════════════════════════════════════════════

class StackBlitzBot:
    """Bot principal pour la création automatisée de comptes StackBlitz"""
    
    def __init__(self):
        self.data_manager = DataManager()
        self.logger = Logger(self.data_manager)
        self.discord_notifier = DiscordNotifier(Config.DISCORD_WEBHOOK_URL, self.data_manager)
        self.browser_manager = None
        self.email_manager = None
        self.registrar = None
        self.running = False
    
    def initialize(self):
        """Initialise tous les composants du bot"""
        self.logger.log_header()
        self._log_configuration()
        
        self.browser_manager = BrowserManager(self.logger)
        driver = self.browser_manager.setup_driver()
        
        self.email_manager = EmailManager(self.browser_manager, self.logger)
        self.registrar = StackBlitzRegistrar(self.browser_manager, self.logger)
        
        self.logger.info("🌐 Serveur web de monitoring démarré")
    
    def _log_configuration(self):
        """Affiche la configuration actuelle"""
        self.logger.info("⚙️ CONFIGURATION ACTUELLE")
        self.logger.info(f"🌐 URL d'inscription: {Config.BOLT_SIGNUP_URL}")
        self.logger.info(f"📊 Mode: {Config.ACCOUNT_CREATION_MODE} ♾️")
        self.logger.info(f"🔐 Mode mot de passe: {Config.PASSWORD_MODE}")
        self.logger.info(f"📁 Fichier de sortie: {Config.CREDENTIALS_FILE}")
        self.logger.info(f"🔔 Discord webhook configuré: ✅")
    
    def create_single_account(self, account_number):
        """Crée un seul compte avec gestion d'erreurs complète"""
        try:
            self.logger.info(f"🎯 Création du compte #{account_number}...")
            self.data_manager.update_stats(attempts=1)
            
            if account_number > 1:
                self.browser_manager.clean_browser_session()
            
            email = self.email_manager.get_temp_email()
            success, username, password = self.registrar.register_account(email)
            
            if success:
                account = self.data_manager.add_account(email, username, password)
                self.logger.log_account_info(email, username, password, account_number)
                
                # Envoyer notification Discord
                self.discord_notifier.send_account_notification(account)
                
                self.logger.info(f"✅ Compte #{account_number} créé avec succès!")
                return True
            else:
                self.data_manager.update_stats(failures=1)
                self.logger.error(f"❌ Échec de la création du compte #{account_number}")
                return False
                
        except Exception as e:
            self.data_manager.update_stats(failures=1)
            self.logger.error(f"❌ Erreur lors de la création du compte #{account_number}: {e}")
            return False
    
    def run_infinite_mode(self):
        """Mode de création infinie jusqu'à interruption"""
        self.logger.info("♾️ MODE INFINI ACTIVÉ - Création continue de comptes StackBlitz 24/7")
        self.logger.info("💡 Appuyez sur Ctrl+C pour arrêter")
        self.logger.info("🚀 Le bot va maintenant créer des comptes en continu...")
        
        account_number = 1
        self.running = True
        
        while self.running:
            try:
                self.create_single_account(account_number)
                account_number += 1
                
                # Envoyer un rapport toutes les 10 comptes
                if account_number % 10 == 0:
                    self.discord_notifier.send_stats_notification()
                    self.logger.info(f"📊 Rapport automatique envoyé - {self.data_manager.stats['successful_accounts']} comptes créés")
                
                time.sleep(5)  # Pause entre les créations
                
            except KeyboardInterrupt:
                self.logger.info("⏹️ Arrêt demandé par l'utilisateur")
                self.running = False
                break
            except Exception as e:
                self.logger.error(f"❌ Erreur inattendue : {e}")
                time.sleep(10)  # Pause plus longue en cas d'erreur
    
    def stop(self):
        """Arrête le bot"""
        self.running = False
        self.logger.info("🛑 Arrêt du bot demandé")
    
    def run(self):
        """Lance le bot selon le mode configuré"""
        try:
            self.initialize()
            self.run_infinite_mode()  # Toujours en mode infini
            
            self._display_final_summary()
            
        except Exception as e:
            self.logger.error(f"❌ Erreur générale : {e}")
        finally:
            self._cleanup()
    
    def _display_final_summary(self):
        """Affiche le résumé final des opérations"""
        print(f"\n{Config.COLORS['BOLD']}{Config.COLORS['PURPLE']}")
        print("╔══════════════════════════════════════════════════════════════════════╗")
        print("║                    📊 RÉSUMÉ MODE INFINI ARRÊTÉ 📊                   ║")
        print("╚══════════════════════════════════════════════════════════════════════╝")
        print(f"{Config.COLORS['RESET']}")

        stats = self.data_manager.stats
        self.logger.info(f"✅ Comptes créés avec succès: {stats['successful_accounts']}")
        self.logger.info(f"❌ Échecs: {stats['failed_attempts']}")
        self.logger.info(f"🎯 Total tentatives: {stats['total_attempts']}")
        self.logger.info(f"📁 Données sauvegardées dans: {Config.CREDENTIALS_FILE}")
        
        if stats['successful_accounts'] > 0:
            success_rate = (stats['successful_accounts'] / stats['total_attempts']) * 100
            self.logger.info(f"📈 Taux de réussite: {success_rate:.1f}%")
            
            # Envoyer résumé Discord
            self.discord_notifier.send_stats_notification()
        
        print(f"\n{Config.COLORS['BOLD']}{Config.COLORS['INFO']}♾️ Mode infini arrêté - Redémarrez pour continuer! ♾️{Config.COLORS['RESET']}\n")
    
    def _cleanup(self):
        """Nettoie les ressources utilisées"""
        self.logger.info("🧹 Nettoyage en cours...")
        if self.browser_manager:
            self.browser_manager.close()
        self.logger.info("👋 Au revoir!")

# ═══════════════════════════════════════════════════════════════════════════════
# 🚀 POINT D'ENTRÉE PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    """Point d'entrée principal du programme"""
    try:
        print(f"\n{Config.COLORS['BOLD']}{Config.COLORS['PURPLE']}")
        print("╔══════════════════════════════════════════════════════════════════════╗")
        print("║                    ♾️ STACKBLITZ BOT MODE INFINI ♾️                  ║")
        print("║                    Création continue 24/7 de comptes                 ║")
        print("╚══════════════════════════════════════════════════════════════════════╝")
        print(f"{Config.COLORS['RESET']}")
        
        bot = StackBlitzBot()
        bot.run()
            
    except KeyboardInterrupt:
        print(f"\n{Config.COLORS['WARNING']}⏹️ Programme interrompu par l'utilisateur{Config.COLORS['RESET']}")
    except Exception as e:
        print(f"\n{Config.COLORS['ERROR']}❌ Erreur fatale: {e}{Config.COLORS['RESET']}")
    finally:
        print(f"{Config.COLORS['DIM']}♾️ StackBlitz Bot Mode Infini - Au revoir! 🤖{Config.COLORS['RESET']}")

if __name__ == "__main__":
    main()