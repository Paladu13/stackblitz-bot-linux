#!/usr/bin/env python3
"""
Script de correction pour le problème distutils avec Python 3.13
"""

import subprocess
import sys
import os

def fix_distutils_issue():
    """Corrige le problème distutils en installant setuptools et en mettant à jour undetected-chromedriver"""
    
    print("🔧 Correction du problème distutils avec Python 3.13...")
    
    try:
        # Installer setuptools qui contient distutils
        print("📦 Installation de setuptools...")
        subprocess.run([sys.executable, "-m", "pip", "install", "setuptools==69.0.0"], check=True)
        
        # Mettre à jour undetected-chromedriver vers une version plus récente
        print("🔄 Mise à jour d'undetected-chromedriver...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "undetected-chromedriver==3.5.5"], check=True)
        
        # Alternative : installer une version de développement si nécessaire
        try:
            print("🧪 Test d'importation...")
            import undetected_chromedriver
            print("✅ undetected_chromedriver importé avec succès")
        except ImportError as e:
            print(f"⚠️ Problème persistant, installation de la version de développement...")
            subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "git+https://github.com/ultrafunkamsterdam/undetected-chromedriver.git"], check=True)
        
        print("✅ Correction terminée avec succès!")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Erreur lors de la correction : {e}")
        return False
    except Exception as e:
        print(f"❌ Erreur inattendue : {e}")
        return False

def test_imports():
    """Test tous les imports nécessaires"""
    print("🧪 Test des imports...")
    
    modules_to_test = [
        "selenium",
        "undetected_chromedriver", 
        "requests",
        "flask",
        "psutil"
    ]
    
    failed_imports = []
    
    for module in modules_to_test:
        try:
            __import__(module)
            print(f"✅ {module} : OK")
        except ImportError as e:
            print(f"❌ {module} : ÉCHEC - {e}")
            failed_imports.append(module)
    
    if failed_imports:
        print(f"\n❌ Modules en échec : {', '.join(failed_imports)}")
        return False
    else:
        print("\n✅ Tous les modules sont correctement importés!")
        return True

if __name__ == "__main__":
    print("🚀 Script de correction pour StackBlitz Bot Linux")
    print("=" * 50)
    
    # Vérifier qu'on est dans l'environnement virtuel
    if not hasattr(sys, 'real_prefix') and not (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        print("⚠️ ATTENTION: Vous n'êtes pas dans l'environnement virtuel!")
        print("Exécutez d'abord : source venv/bin/activate")
        sys.exit(1)
    
    # Appliquer les corrections
    if fix_distutils_issue():
        # Tester les imports
        if test_imports():
            print("\n🎉 Correction réussie! Le bot devrait maintenant fonctionner.")
        else:
            print("\n❌ Certains modules ont encore des problèmes.")
            sys.exit(1)
    else:
        print("\n❌ Échec de la correction.")
        sys.exit(1)