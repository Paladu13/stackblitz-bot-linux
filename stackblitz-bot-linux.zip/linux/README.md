# 🤖 StackBlitz Bot Linux - Mode Infini ♾️

Bot automatisé pour la création INFINIE de comptes StackBlitz 24/7 sur Linux/VPS.

## ✨ Fonctionnalités

- ♾️ **MODE INFINI EXCLUSIF** - Création automatique continue 24/7
- 📧 Gestion d'emails temporaires (22.do)
- 🔔 Notifications Discord via webhook
- 📊 Rapports automatiques toutes les 10 créations
- 📝 Logs détaillés
- 🔧 Service systemd intégré
- 🐧 Optimisé pour Linux/VPS
- 🚀 **AUCUNE LIMITE** - Fonctionne en continu jusqu'à interruption

## 🚀 Installation rapide

```bash
# 1. Télécharger et extraire le projet
wget https://github.com/votre-repo/stackblitz-bot-linux.zip
unzip stackblitz-bot-linux.zip
cd stackblitz-bot-linux

# 2. Lancer l'installation automatique
chmod +x install.sh
./install.sh

# 3. Démarrer le service
sudo systemctl start stackblitz-bot
```

## ⚙️ Configuration

Modifiez les paramètres dans `stackblitz_bot.py` :

```python
class Config:
    # URL d'inscription (MODIFIEZ CETTE URL)
    BOLT_SIGNUP_URL = "https://bolt.new/?rid=VOTRE_ID"
    
    # Webhook Discord (REMPLACEZ PAR LE VÔTRE)
    DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/VOTRE_WEBHOOK"
    
    # Mode de création (TOUJOURS INFINI)
    ACCOUNT_CREATION_MODE = "infinite"  # ♾️ Mode infini exclusif
    
    # Configuration des mots de passe
    PASSWORD_MODE = "random"  # "random" ou "custom"
    CUSTOM_PASSWORD = "VotreMotDePasse123!"
```

## 🎛️ Commandes de gestion

```bash
# Démarrer le bot
sudo systemctl start stackblitz-bot

# Arrêter le bot
sudo systemctl stop stackblitz-bot

# Redémarrer le bot
sudo systemctl restart stackblitz-bot

# Voir le statut
sudo systemctl status stackblitz-bot

# Voir les logs en temps réel
sudo journalctl -u stackblitz-bot -f

# Voir les logs récents
sudo journalctl -u stackblitz-bot -n 100
```

## 📁 Structure des fichiers

```
stackblitz-bot-linux/
├── stackblitz_bot.py          # Script principal
├── requirements.txt           # Dépendances Python
├── install.sh                # Script d'installation
├── README.md                 # Documentation
├── stackblitz_credentials.json  # Données des comptes (généré)
└── stackblitz_automation.log   # Fichier de logs (généré)
```

## 🔔 Configuration Discord

1. Créez un webhook Discord dans votre serveur
2. Copiez l'URL du webhook
3. Remplacez `DISCORD_WEBHOOK_URL` dans la configuration
4. **Rapports automatiques** toutes les 10 créations incluront :
   - ✅ Nouveaux comptes créés
   - 📊 Statistiques périodiques
   - ❌ Erreurs importantes

## 🛠️ Dépannage

### Le bot ne démarre pas
```bash
# Vérifier les logs
sudo journalctl -u stackblitz-bot -n 50

# Vérifier la configuration
python3 -c "import stackblitz_bot; print('Configuration OK')"

# Tester manuellement
python3 stackblitz_bot.py
```

### Chrome ne fonctionne pas
```bash
# Réinstaller Chrome
sudo apt-get remove google-chrome-stable
sudo apt-get install google-chrome-stable

# Vérifier la version
google-chrome --version
```

### Problèmes de permissions
```bash
# Réparer les permissions
chmod +x stackblitz_bot.py
chown -R $USER:$USER .
```

## 📈 Monitoring et maintenance

### Logs importants à surveiller
- `stackblitz_automation.log` : Logs détaillés du bot
- `sudo journalctl -u stackblitz-bot -f` : Logs système en temps réel

### Fichiers de données
- `stackblitz_credentials.json` : Comptes créés (SAUVEGARDEZ CE FICHIER)
- **Sauvegarde automatique** à chaque création

### Maintenance recommandée
```bash
# Mise à jour hebdomadaire
sudo apt-get update && sudo apt-get upgrade

# Nettoyage des logs (si nécessaire)
sudo journalctl --vacuum-time=7d

# Sauvegarde des données
cp stackblitz_credentials.json backup_$(date +%Y%m%d).json
```

## 🔒 Sécurité

- ✅ Exécution en utilisateur non-root
- ✅ Environnement virtuel Python isolé
- ✅ Firewall configuré automatiquement
- ✅ Logs sécurisés
- ⚠️ Changez les mots de passe par défaut
- ⚠️ Utilisez HTTPS en production (reverse proxy recommandé)

## 📞 Support

En cas de problème :
1. Consultez les logs : `sudo journalctl -u stackblitz-bot -f`
2. Vérifiez la configuration dans `stackblitz_bot.py`
3. Testez manuellement : `python3 stackblitz_bot.py`
4. Redémarrez le service : `sudo systemctl restart stackblitz-bot`

## 🎯 Optimisations VPS

Pour de meilleures performances sur VPS :
- Minimum 1GB RAM recommandé
- 2 CPU cores pour de meilleures performances
- Connexion internet stable
- Ubuntu 20.04+ ou CentOS 8+ recommandé
- **Mode infini** : Le bot fonctionne 24/7 automatiquement

---

**♾️ MODE INFINI EXCLUSIF ! Création continue de comptes StackBlitz 24/7 sans limite ! 🤖**
**🚀 Démarrez le service et laissez-le tourner en permanence ! ♾️**