#!/bin/bash

# ═══════════════════════════════════════════════════════════════════════════════
# 🚀 SCRIPT D'INSTALLATION STACKBLITZ BOT LINUX
# ═══════════════════════════════════════════════════════════════════════════════

set -e  # Arrêter en cas d'erreur

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
BOLD='\033[1m'

# Fonction d'affichage avec style
print_header() {
    echo -e "\n${PURPLE}${BOLD}╔══════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}${BOLD}║                    🤖 STACKBLITZ BOT INSTALLER 🤖                   ║${NC}"
    echo -e "${PURPLE}${BOLD}║                         Installation Linux VPS                       ║${NC}"
    echo -e "${PURPLE}${BOLD}╚══════════════════════════════════════════════════════════════════════╝${NC}\n"
}

print_step() {
    echo -e "\n${CYAN}${BOLD}🔧 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Vérification des privilèges root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        print_warning "Ce script ne doit pas être exécuté en tant que root pour des raisons de sécurité."
        print_info "Veuillez l'exécuter avec un utilisateur normal ayant les privilèges sudo."
        exit 1
    fi
}

# Détection de la distribution Linux
detect_os() {
    print_step "Détection du système d'exploitation..."
    
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
        print_success "Système détecté: $OS $VER"
    else
        print_error "Impossible de détecter le système d'exploitation"
        exit 1
    fi
}

# Mise à jour du système
update_system() {
    print_step "Mise à jour du système..."
    
    if command -v apt-get &> /dev/null; then
        sudo apt-get update -y
        sudo apt-get upgrade -y
        print_success "Système mis à jour (APT)"
    elif command -v yum &> /dev/null; then
        sudo yum update -y
        print_success "Système mis à jour (YUM)"
    elif command -v dnf &> /dev/null; then
        sudo dnf update -y
        print_success "Système mis à jour (DNF)"
    else
        print_warning "Gestionnaire de paquets non reconnu, mise à jour manuelle requise"
    fi
}

# Installation des dépendances système
install_system_dependencies() {
    print_step "Installation des dépendances système..."
    
    if command -v apt-get &> /dev/null; then
        sudo apt-get install -y \
            python3 \
            python3-pip \
            python3-venv \
            wget \
            curl \
            unzip \
            xvfb \
            libxi6 \
            gconf-gsettings-backend \
            libnss3 \
            libxss1 \
            libxrandr2 \
            libasound2 \
            libpangocairo-1.0-0 \
            libatk1.0-0 \
            libcairo-gobject2 \
            libgtk-3-0 \
            libgdk-pixbuf2.0-0 \
            fonts-liberation \
            libayatana-appindicator3-1 \
            xdg-utils \
            ca-certificates \
            gnupg \
            lsb-release
        print_success "Dépendances système installées (APT)"
    elif command -v yum &> /dev/null; then
        sudo yum install -y \
            python3 \
            python3-pip \
            wget \
            curl \
            unzip \
            xorg-x11-server-Xvfb \
            libXi \
            GConf2 \
            nss \
            libXss \
            libXrandr \
            alsa-lib \
            pango \
            atk \
            cairo-gobject \
            gtk3 \
            gdk-pixbuf2 \
            liberation-fonts \
            libappindicator-gtk3 \
            xdg-utils
        print_success "Dépendances système installées (YUM)"
    else
        print_error "Gestionnaire de paquets non supporté"
        exit 1
    fi
}

# Installation de Google Chrome
install_chrome() {
    print_step "Installation de Google Chrome..."
    
    if command -v google-chrome &> /dev/null; then
        print_success "Google Chrome déjà installé"
        return
    fi
    
    if command -v apt-get &> /dev/null; then
        # Méthode moderne pour ajouter la clé GPG
        wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo gpg --dearmor -o /usr/share/keyrings/google-chrome-keyring.gpg
        echo "deb [arch=amd64 signed-by=/usr/share/keyrings/google-chrome-keyring.gpg] http://dl.google.com/linux/chrome/deb/ stable main" | sudo tee /etc/apt/sources.list.d/google-chrome.list
        sudo apt-get update -y
        sudo apt-get install -y google-chrome-stable
    elif command -v yum &> /dev/null; then
        sudo yum install -y https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
    else
        print_error "Installation de Chrome non supportée pour ce système"
        exit 1
    fi
    
    print_success "Google Chrome installé"
}

# Création de l'environnement virtuel Python
setup_python_env() {
    print_step "Configuration de l'environnement Python..."
    
    # Créer l'environnement virtuel
    python3 -m venv venv
    source venv/bin/activate
    
    # Mise à jour de pip
    pip install --upgrade pip
    
    # Installation des dépendances Python
    pip install -r requirements.txt
    
    print_success "Environnement Python configuré pour le mode infini"
}

# Configuration des permissions et services
setup_permissions() {
    print_step "Configuration des permissions..."
    
    # Rendre le script principal exécutable
    chmod +x stackblitz_bot.py
    
    # Créer les dossiers nécessaires
    mkdir -p logs
    mkdir -p data
    
    print_success "Permissions configurées"
}

# Création du service systemd
create_service() {
    print_step "Création du service systemd..."
    
    CURRENT_DIR=$(pwd)
    USER=$(whoami)
    
    sudo tee /etc/systemd/system/stackblitz-bot.service > /dev/null <<EOF
[Unit]
Description=StackBlitz Bot Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$CURRENT_DIR
Environment=PATH=$CURRENT_DIR/venv/bin
ExecStart=$CURRENT_DIR/venv/bin/python $CURRENT_DIR/stackblitz_bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable stackblitz-bot.service
    
    print_success "Service systemd créé et activé"
}

# Test de l'installation
test_installation() {
    print_step "Test de l'installation..."
    
    # Activer l'environnement virtuel
    source venv/bin/activate
    
    # Test d'importation des modules
    python3 -c "
import selenium
import undetected_chromedriver
import requests
print('✅ Tous les modules Python pour le mode infini sont installés')
"
    
    # Test de Chrome
    if command -v google-chrome &> /dev/null; then
        google-chrome --version
        print_success "Google Chrome installé et fonctionnel"
    else
        print_error "Google Chrome non trouvé"
        exit 1
    fi
    
    print_success "Installation testée avec succès"
}

# Affichage des informations finales
show_final_info() {
    print_step "Installation terminée!"
    
    echo -e "\n${GREEN}${BOLD}🎉 StackBlitz Bot installé avec succès! 🎉${NC}\n"
    
    echo -e "${CYAN}📋 Commandes utiles:${NC}"
    echo -e "  • Démarrer le bot:     ${YELLOW}sudo systemctl start stackblitz-bot${NC}"
    echo -e "  • Arrêter le bot:      ${YELLOW}sudo systemctl stop stackblitz-bot${NC}"
    echo -e "  • Statut du bot:       ${YELLOW}sudo systemctl status stackblitz-bot${NC}"
    echo -e "  • Logs du bot:         ${YELLOW}sudo journalctl -u stackblitz-bot -f${NC}"
    echo -e "  • Redémarrer le bot:   ${YELLOW}sudo systemctl restart stackblitz-bot${NC}"
    
    echo -e "\n${CYAN}♾️ Mode Infini:${NC}"
    echo -e "  • Le bot crée des comptes en continu 24/7"
    echo -e "  • Rapports Discord automatiques toutes les 10 créations"
    echo -e "  • Arrêt uniquement par commande manuelle"
    
    echo -e "\n${CYAN}📁 Fichiers importants:${NC}"
    echo -e "  • Configuration:       ${YELLOW}stackblitz_bot.py${NC} (modifiez les paramètres en haut du fichier)"
    echo -e "  • Données des comptes: ${YELLOW}stackblitz_credentials.json${NC}"
    echo -e "  • Logs:                ${YELLOW}stackblitz_automation.log${NC}"
    
    echo -e "\n${CYAN}🔧 Configuration:${NC}"
    echo -e "  • Modifiez les paramètres dans ${YELLOW}stackblitz_bot.py${NC}"
    echo -e "  • Redémarrez le service après modification: ${YELLOW}sudo systemctl restart stackblitz-bot${NC}"
    
    echo -e "\n${GREEN}${BOLD}♾️ Le bot mode infini est prêt ! Création continue 24/7 ! 🚀${NC}\n"
}

# Fonction principale
main() {
    print_header
    
    check_root
    detect_os
    update_system
    install_system_dependencies
    install_chrome
    setup_python_env
    setup_permissions
    create_service
    test_installation
    show_final_info
}

# Gestion des erreurs
trap 'print_error "Installation interrompue"; exit 1' INT TERM

# Exécution du script principal
main "$@"